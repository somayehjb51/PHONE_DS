class ContactNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class PhoneBookBST:
    def __init__(self):
        self.root = None
    
    def add_contact(self, name, phone):
        if not self._is_valid_name(name):
            print("Error: Name must contain only English letters")
            return False
        
        new_node = ContactNode(name, phone)
        
        if self.root is None:
            self.root = new_node
            print(f"Contact '{name}' added")
            return True
        
        return self._add_recursive(self.root, new_node)
    
    def _add_recursive(self, current, new_node):
        if new_node.name == current.name:
            print(f"Error: Name '{new_node.name}' already exists")
            return False
        
        if new_node.name < current.name:
            if current.left is None:
                current.left = new_node
                print(f"Contact '{new_node.name}' added")
                return True
            return self._add_recursive(current.left, new_node)
        else:
            if current.right is None:
                current.right = new_node
                print(f"Contact '{new_node.name}' added")
                return True
            return self._add_recursive(current.right, new_node)
    
    def search_contact(self, name):
        result = self._search_recursive(self.root, name)
        if result:
            print(f"Name: {result.name}, Phone: {result.phone}")
        else:
            print(f"Contact '{name}' not found")
        return result
    
    def _search_recursive(self, current, name):
        if current is None:
            return None
        
        if name == current.name:
            return current
        elif name < current.name:
            return self._search_recursive(current.left, name)
        else:
            return self._search_recursive(current.right, name)
    
    def delete_contact(self, name):
        self.root = self._delete_recursive(self.root, name)
    
    def _delete_recursive(self, current, name):
        if current is None:
            print(f"Contact '{name}' not found")
            return None
        
        if name < current.name:
            current.left = self._delete_recursive(current.left, name)
        elif name > current.name:
            current.right = self._delete_recursive(current.right, name)
        else:
            print(f"Contact '{name}' deleted")
            
            if current.left is None and current.right is None:
                return None
            
            if current.left is None:
                return current.right
            if current.right is None:
                return current.left
            
            min_node = self._find_min(current.right)
            current.name = min_node.name
            current.phone = min_node.phone
            current.right = self._delete_recursive(current.right, min_node.name)
        
        return current
    
    def _find_min(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current
    
    def display_all(self):
        if self.root is None:
            print("Phone book is empty")
            return
        
        print("\nAll contacts (sorted by name):")
        print("-" * 40)
        self._inorder_traversal(self.root)
        print("-" * 40)
    
    def _inorder_traversal(self, node):
        if node is not None:
            self._inorder_traversal(node.left)
            print(f"Name: {node.name:<15} Phone: {node.phone}")
            self._inorder_traversal(node.right)
    
    def display_tree(self):
        print("\nTree structure:")
        self._print_tree(self.root, "", True)
    def _print_tree(self, node, prefix, is_left):
        if node is not None:
            print(prefix + ("├── " if is_left else "└── ") + node.name)
            self._print_tree(node.left, prefix + ("│   " if is_left else "    "), True)
            self._print_tree(node.right, prefix + ("│   " if is_left else "    "), False)
    
    def _is_valid_name(self, name):
        return name.isalpha()
    
    def count_contacts(self):
        return self._count_recursive(self.root)
    
    def _count_recursive(self, node):
        if node is None:
            return 0
        return 1 + self._count_recursive(node.left) + self._count_recursive(node.right)


def main():
    phone_book = PhoneBookBST()
    
    print("Phone Book with Binary Search Tree")
    print("=" * 50)
    
    sample_data = [
        ("Alice", "09123456789"),
        ("Bob", "09129876543"),
        ("Charlie", "09331234567"),
        ("David", "09121112222"),
        ("Eve", "09334445556")
    ]
    
    for name, phone in sample_data:
        phone_book.add_contact(name, phone)
    
    while True:
        print("\nMain Menu:")
        print("1. Add new contact")
        print("2. Search contact")
        print("3. Delete contact")
        print("4. Display all contacts")
        print("5. Display tree structure")
        print("6. Count contacts")
        print("7. Exit")
        
        choice = input("\nYour choice: ").strip()
        
        if choice == "1":
            name = input("Contact name (English letters only): ").strip()
            phone = input("Phone number: ").strip()
            phone_book.add_contact(name, phone)
        
        elif choice == "2":
            name = input("Name to search: ").strip()
            phone_book.search_contact(name)
        
        elif choice == "3":
            name = input("Name to delete: ").strip()
            phone_book.delete_contact(name)
        
        elif choice == "4":
            phone_book.display_all()
        
        elif choice == "5":
            phone_book.display_tree()
        
        elif choice == "6":
            count = phone_book.count_contacts()
            print(f"Total contacts: {count}")
        
        elif choice == "7":
            print("Exiting program...")
            break
        
        else:
            print("Invalid input. Please enter 1-7.")


if __name__ == "__main__":
    main()